from contextlib import asynccontextmanager
from uuid import UUID, uuid4

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import JSONResponse

from app.core.config import get_settings
from app.db import close_pool, get_connection, open_pool
from app.schemas import (
    ContextResponse,
    CoreResponse,
    CreateEventRequest,
    EventResponse,
    CreateMemoryRequest,
    IncomingMessage,
    MemoryResponse,
    ToolExecuteRequest,
    ToolExecuteResponse,
    BrainRequest,
    BrainResponse,
    AutopilotResponse,
    AutopilotEventResponse,
    BusinessBrainAnalyzeRequest,
    BusinessBrainAnalyzeResponse,
    InsightStatusRequest,
    RecommendationStatusRequest,
)
from app.services.context_manager import ContextManager
from app.services.event_engine import EventEngine, EventProcessingError
from app.services.core_service import GalaxyCoreService
from app.services.memory_service import MemoryService
from app.services.tool_manager import ToolExecutionError, ToolManager
from app.services.brain_service import BrainService
from app.services.business_brain_service import BusinessBrainError, BusinessBrainService
from app.services.recommendation_engine import RecommendationEngineError, RecommendationEngine
from app.services.tool_registry import list_tools
from app.services.autopilot_service import GalaxyAutopilotService
from app.services.system_diagnostics import DiagnosticsService


settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    open_pool()
    yield
    close_pool()


app = FastAPI(
    title="Galaxy Core",
    description="Galaxy Business Autopilot MVP integrado.",
    version="1.0.0",
    lifespan=lifespan,
)


@app.middleware("http")
async def request_id_middleware(request: Request, call_next):
    request_id = request.headers.get("X-Request-ID") or str(uuid4())
    request.state.request_id = request_id
    response = await call_next(request)
    response.headers["X-Request-ID"] = request_id
    return response


@app.get("/health")
def health() -> dict:
    return {
        "status": "ok",
        "service": "galaxy-core",
        "version": "1.0.0",
    }


@app.get("/health/ready")
async def readiness() -> dict:
    try:
        async with get_connection() as conn:
            service = DiagnosticsService(conn)
            result = service.readiness()
    except Exception as exc:
        result = {
            "status": "not_ready",
            "service": "galaxy-core",
            "version": "1.1.0",
            "checks": {
                "database": {"ok": False, "error": str(exc)},
                "required_tables": {"ok": False, "missing": []},
                "gemini_configuration": {
                    "ok": bool(settings.gemini_api_key.strip()),
                    "configured": bool(settings.gemini_api_key.strip()),
                    "model": settings.gemini_model,
                },
            },
        }
    return JSONResponse(
        status_code=200 if result.get("status") == "ready" else 503,
        content=result,
    )


@app.get("/api/v1/system/diagnostics")
async def system_diagnostics() -> dict:
    try:
        async with get_connection() as conn:
            service = DiagnosticsService(conn)
            return service.diagnostics()
    except Exception as exc:
        return {
            "status": "degraded",
            "service": "galaxy-core",
            "version": "1.1.0",
            "database": {"ok": False, "error": str(exc)},
            "schema": {"ok": False, "missing_tables": []},
            "gemini": {
                "configured": bool(settings.gemini_api_key.strip()),
                "model": settings.gemini_model,
                "api_key_exposed": False,
            },
            "tool_registry": {"ok": False, "tool_count": 0},
            "components": {},
        }


@app.get("/health/db")
async def database_health() -> dict:
    async with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT current_database(), version()")
            database, version = cur.fetchone()
    return {
        "status": "ok",
        "database": database,
        "postgres_version": version,
    }


@app.post("/api/v1/messages", response_model=CoreResponse)
async def receive_message(payload: IncomingMessage) -> CoreResponse:
    async with get_connection() as conn:
        service = GalaxyCoreService(conn)
        result = service.handle_incoming_message(payload)
    return CoreResponse(**result)


@app.post("/api/v1/memory", response_model=MemoryResponse)
async def create_memory(payload: CreateMemoryRequest) -> MemoryResponse:
    async with get_connection() as conn:
        service = MemoryService(conn)
        try:
            memory_id = service.create_memory(
                business_id=payload.business_id,
                customer_id=payload.customer_id,
                conversation_id=payload.conversation_id,
                user_id=payload.user_id,
                memory_type=payload.memory_type,
                memory_key=payload.memory_key,
                content=payload.content,
                source=payload.source,
                confidence=payload.confidence,
                importance=payload.importance,
                metadata=payload.metadata,
            )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
    return MemoryResponse(success=True, memory_id=memory_id)


@app.get("/api/v1/context", response_model=ContextResponse)
async def get_context(
    business_id: UUID,
    customer_id: UUID | None = None,
    conversation_id: UUID | None = None,
    memory_limit: int = Query(default=10, ge=1, le=50),
) -> ContextResponse:
    async with get_connection() as conn:
        manager = ContextManager(conn)
        context = manager.build_context(
            business_id=business_id,
            customer_id=customer_id,
            conversation_id=conversation_id,
            memory_limit=memory_limit,
        )

    if not context.get("found"):
        return ContextResponse(
            found=False,
            reason=context.get("reason"),
            context=None,
        )

    return ContextResponse(found=True, context=context)


@app.get("/api/v1/tools")
def get_tools() -> dict:
    return {"tools": list_tools()}


@app.post("/api/v1/events", response_model=EventResponse)
async def receive_event(payload: CreateEventRequest) -> EventResponse:
    async with get_connection() as conn:
        engine = EventEngine(conn)
        try:
            result = engine.receive_and_process(
                business_id=payload.business_id,
                event_type=payload.event_type,
                source=payload.source,
                priority=payload.priority,
                entity_type=payload.entity_type,
                entity_id=payload.entity_id,
                payload=payload.payload,
                event_id=payload.event_id,
                occurred_at=payload.occurred_at,
            )
        except EventProcessingError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
    return EventResponse(**result)


@app.post("/api/v1/tools/execute", response_model=ToolExecuteResponse)
async def execute_tool(payload: ToolExecuteRequest) -> ToolExecuteResponse:
    async with get_connection() as conn:
        manager = ToolManager(conn)
        try:
            result = manager.execute(
                business_id=payload.business_id,
                tool_name=payload.tool_name,
                inputs=payload.inputs,
                requested_by_user_id=payload.requested_by_user_id,
            )
        except ToolExecutionError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
    return ToolExecuteResponse(**result)


@app.post("/api/v1/business-brain/analyze", response_model=BusinessBrainAnalyzeResponse)
async def analyze_business(payload: BusinessBrainAnalyzeRequest) -> BusinessBrainAnalyzeResponse:
    async with get_connection() as conn:
        service = BusinessBrainService(conn)
        try:
            result = service.analyze(
                business_id=payload.business_id,
                focus=payload.focus,
                event_id=payload.event_id,
            )
        except BusinessBrainError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Business Brain error: {exc}") from exc
    return BusinessBrainAnalyzeResponse(**result)


@app.get("/api/v1/business-brain/insights")
async def list_business_insights(
    business_id: UUID,
    status: str = Query(default="open"),
    limit: int = Query(default=50, ge=1, le=100),
) -> dict:
    async with get_connection() as conn:
        service = BusinessBrainService(conn)
        try:
            insights = service.list_insights(
                business_id=business_id,
                status=status,
                limit=limit,
            )
        except BusinessBrainError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"success": True, "insights": insights}


@app.patch("/api/v1/business-brain/insights/{insight_id}")
async def update_business_insight(
    insight_id: UUID,
    payload: InsightStatusRequest,
    business_id: UUID = Query(...),
) -> dict:
    async with get_connection() as conn:
        service = BusinessBrainService(conn)
        try:
            insight = service.acknowledge_insight(
                business_id=business_id,
                insight_id=insight_id,
                status=payload.status,
            )
        except BusinessBrainError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"success": True, "insight": insight}


@app.get("/api/v1/recommendations")
async def list_recommendations(
    business_id: UUID,
    status: str = Query(default="pending"),
    limit: int = Query(default=50, ge=1, le=100),
) -> dict:
    async with get_connection() as conn:
        service = RecommendationEngine(conn)
        try:
            recommendations = service.list_recommendations(
                business_id=business_id,
                status=status,
                limit=limit,
            )
        except RecommendationEngineError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"success": True, "recommendations": recommendations}


@app.patch("/api/v1/recommendations/{recommendation_id}")
async def update_recommendation(
    recommendation_id: UUID,
    payload: RecommendationStatusRequest,
    business_id: UUID = Query(...),
) -> dict:
    async with get_connection() as conn:
        service = RecommendationEngine(conn)
        try:
            recommendation = service.update_status(
                business_id=business_id,
                recommendation_id=recommendation_id,
                status=payload.status,
            )
        except RecommendationEngineError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"success": True, "recommendation": recommendation}


@app.post("/api/v1/autopilot/respond", response_model=AutopilotResponse)
async def autopilot_respond(payload: IncomingMessage) -> AutopilotResponse:
    """Run the integrated customer-facing MVP cycle."""
    async with get_connection() as conn:
        service = GalaxyAutopilotService(conn)
        try:
            result = service.respond(payload)
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(
                status_code=502,
                detail=f"Galaxy Autopilot error: {exc}",
            ) from exc
    return AutopilotResponse(**result)


@app.post("/api/v1/autopilot/event", response_model=AutopilotEventResponse)
async def autopilot_event(payload: CreateEventRequest) -> AutopilotEventResponse:
    """Run the integrated event -> Business Brain MVP cycle."""
    async with get_connection() as conn:
        service = GalaxyAutopilotService(conn)
        try:
            result = service.process_event(payload)
        except Exception as exc:
            raise HTTPException(
                status_code=502,
                detail=f"Galaxy Autopilot event error: {exc}",
            ) from exc
    return AutopilotEventResponse(**result)


@app.post("/api/v1/autopilot/business-analysis", response_model=BusinessBrainAnalyzeResponse)
async def autopilot_business_analysis(
    payload: BusinessBrainAnalyzeRequest,
) -> BusinessBrainAnalyzeResponse:
    """Run Business Brain + Recommendation Engine through the integrated facade."""
    async with get_connection() as conn:
        service = GalaxyAutopilotService(conn)
        try:
            result = service.analyze_business(payload)
        except Exception as exc:
            raise HTTPException(
                status_code=502,
                detail=f"Galaxy Autopilot business-analysis error: {exc}",
            ) from exc
    return BusinessBrainAnalyzeResponse(**result)


@app.post("/api/v1/brain/respond", response_model=BrainResponse)
async def brain_respond(payload: BrainRequest) -> BrainResponse:
    async with get_connection() as conn:
        service = BrainService(conn)
        try:
            result = service.respond(
                business_id=payload.business_id,
                customer_id=payload.customer_id,
                conversation_id=payload.conversation_id,
                user_message=payload.message,
            )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except Exception as exc:
            raise HTTPException(status_code=502, detail=f"Galaxy Brain error: {exc}") from exc
    return BrainResponse(**result)
