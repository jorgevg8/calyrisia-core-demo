from uuid import UUID

import psycopg
from fastapi import HTTPException

from app.schemas import IncomingMessage


class GalaxyCoreService:
    def __init__(self, conn):
        self.conn = conn

    def _business_exists(self, business_id: UUID) -> bool:
        with self.conn.cursor() as cur:
            cur.execute(
                "SELECT 1 FROM businesses WHERE id = %s",
                (business_id,),
            )
            return cur.fetchone() is not None

    def _conversation_belongs_to_business(self, conversation_id: UUID, business_id: UUID) -> bool:
        with self.conn.cursor() as cur:
            cur.execute(
                "SELECT 1 FROM conversations WHERE id = %s AND business_id = %s",
                (conversation_id, business_id),
            )
            return cur.fetchone() is not None

    def handle_incoming_message(self, payload: IncomingMessage) -> dict:
        if not self._business_exists(payload.business_id):
            raise HTTPException(status_code=404, detail="Business not found")

        if payload.conversation_id:
            if not self._conversation_belongs_to_business(
                payload.conversation_id, payload.business_id
            ):
                raise HTTPException(
                    status_code=404,
                    detail="Conversation not found for this business",
                )
            conversation_id = payload.conversation_id
        else:
            with self.conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO conversations (
                        business_id,
                        customer_id,
                        channel,
                        status,
                        started_at,
                        last_message_at,
                        metadata
                    )
                    VALUES (%s, %s, %s, 'active', NOW(), NOW(), %s::jsonb)
                    RETURNING id
                    """,
                    (
                        payload.business_id,
                        payload.customer_id,
                        payload.channel,
                        psycopg.types.json.Jsonb(payload.metadata),
                    ),
                )
                conversation_id = cur.fetchone()[0]

        with self.conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO conversation_messages (
                    business_id,
                    conversation_id,
                    customer_id,
                    sender_type,
                    direction,
                    message_type,
                    content,
                    metadata
                )
                VALUES (%s, %s, %s, 'customer', 'inbound', 'text', %s, %s::jsonb)
                RETURNING id
                """,
                (
                    payload.business_id,
                    conversation_id,
                    payload.customer_id,
                    payload.message,
                    psycopg.types.json.Jsonb(payload.metadata),
                ),
            )
            message_id = cur.fetchone()[0]

            cur.execute(
                """
                UPDATE conversations
                SET last_message_at = NOW(), updated_at = NOW()
                WHERE id = %s
                """,
                (conversation_id,),
            )

        self.conn.commit()

        return {
            "success": True,
            "stage": "received",
            "business_id": payload.business_id,
            "customer_id": payload.customer_id,
            "conversation_id": conversation_id,
            "message_id": message_id,
            "next_component": "galaxy_brain",
        }
