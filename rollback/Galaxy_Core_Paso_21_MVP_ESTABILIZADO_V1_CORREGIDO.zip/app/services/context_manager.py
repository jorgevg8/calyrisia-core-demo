from __future__ import annotations

from typing import Any
from uuid import UUID

from psycopg.errors import UndefinedTable

from app.services.memory_service import MemoryService


class ContextManager:
    """Builds the minimum useful context for a Galaxy decision."""

    def __init__(self, conn):
        self.conn = conn
        self.memory = MemoryService(conn)

    def _get_business(self, business_id: UUID) -> dict[str, Any] | None:
        with self.conn.cursor() as cur:
            cur.execute(
                """
                SELECT id, name, legal_name, business_type, description,
                       phone, email, website, timezone, currency, status
                FROM businesses
                WHERE id = %s
                """,
                (business_id,),
            )
            row = cur.fetchone()
        if not row:
            return None
        return {
            "id": row[0],
            "name": row[1],
            "legal_name": row[2],
            "business_type": row[3],
            "description": row[4],
            "phone": row[5],
            "email": row[6],
            "website": row[7],
            "timezone": row[8],
            "currency": row[9],
            "status": row[10],
        }

    def _get_profile(self, business_id: UUID) -> dict[str, Any] | None:
        with self.conn.cursor() as cur:
            cur.execute(
                """
                SELECT id, industry, short_description, legal_name,
                       address, city, state_province, country, postal_code,
                       operating_hours, policies, processes, objectives,
                       autonomy_config, communication_config, social_links,
                       additional_settings, profile_version, status
                FROM business_profiles
                WHERE business_id = %s AND status = 'active'
                LIMIT 1
                """,
                (business_id,),
            )
            row = cur.fetchone()
        if not row:
            return None
        keys = [
            "id", "industry", "short_description", "legal_name", "address",
            "city", "state_province", "country", "postal_code",
            "operating_hours", "policies", "processes", "objectives",
            "autonomy_config", "communication_config", "social_links",
            "additional_settings", "profile_version", "status",
        ]
        return dict(zip(keys, row))

    def _get_customer(self, business_id: UUID, customer_id: UUID | None) -> dict[str, Any] | None:
        if customer_id is None:
            return None
        with self.conn.cursor() as cur:
            cur.execute(
                """
                SELECT id, full_name, email, phone, status,
                       source, first_contact_at, last_interaction_at, notes
                FROM customers
                WHERE id = %s AND business_id = %s
                """,
                (customer_id, business_id),
            )
            row = cur.fetchone()
        if not row:
            return None
        keys = [
            "id", "full_name", "email", "phone", "status", "source",
            "first_contact_at", "last_interaction_at", "notes",
        ]
        return dict(zip(keys, row))

    def _get_conversation(self, business_id: UUID, conversation_id: UUID | None) -> dict[str, Any] | None:
        if conversation_id is None:
            return None

        with self.conn.cursor() as cur:
            cur.execute(
                """
                SELECT id, customer_id, channel, status, intent, topic, outcome,
                       handoff_to_human, transfer_reason, started_at, last_message_at,
                       closed_at, metadata
                FROM conversations
                WHERE id = %s AND business_id = %s
                """,
                (conversation_id, business_id),
            )
            row = cur.fetchone()
            if not row:
                return None

            cur.execute(
                """
                SELECT id, sender_type, direction, message_type, content,
                       intent, sentiment, tool_used, action_taken, created_at
                FROM conversation_messages
                WHERE conversation_id = %s AND business_id = %s
                ORDER BY created_at DESC
                LIMIT 12
                """,
                (conversation_id, business_id),
            )
            message_rows = cur.fetchall()

        conversation = {
            "id": row[0],
            "customer_id": row[1],
            "channel": row[2],
            "status": row[3],
            "intent": row[4],
            "topic": row[5],
            "outcome": row[6],
            "handoff_to_human": row[7],
            "transfer_reason": row[8],
            "started_at": row[9],
            "last_message_at": row[10],
            "closed_at": row[11],
            "metadata": row[12],
        }
        conversation["recent_messages"] = [
            {
                "id": m[0],
                "sender_type": m[1],
                "direction": m[2],
                "message_type": m[3],
                "content": m[4],
                "intent": m[5],
                "sentiment": m[6],
                "tool_used": m[7],
                "action_taken": m[8],
                "created_at": m[9],
            }
            for m in reversed(message_rows)
        ]
        return conversation

    def build_context(
        self,
        *,
        business_id: UUID,
        customer_id: UUID | None = None,
        conversation_id: UUID | None = None,
        memory_limit: int = 10,
    ) -> dict[str, Any]:
        business = self._get_business(business_id)
        if business is None:
            return {"found": False, "reason": "business_not_found"}

        profile = self._get_profile(business_id)
        customer = self._get_customer(business_id, customer_id)
        conversation = self._get_conversation(business_id, conversation_id)
        memories = self.memory.get_recent_memories(
            business_id=business_id,
            customer_id=customer_id,
            limit=memory_limit,
        )

        return {
            "found": True,
            "business": business,
            "business_profile": profile,
            "customer": customer,
            "conversation": conversation,
            "memories": memories,
        }
