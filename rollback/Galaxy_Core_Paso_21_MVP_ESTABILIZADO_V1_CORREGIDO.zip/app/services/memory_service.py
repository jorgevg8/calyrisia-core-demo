from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from psycopg.types.json import Jsonb


class MemoryService:
    """Persistence layer for Galaxy's structured memory."""

    def __init__(self, conn):
        self.conn = conn

    def create_memory(
        self,
        *,
        business_id: UUID,
        memory_type: str,
        memory_key: str,
        content: str,
        customer_id: UUID | None = None,
        conversation_id: UUID | None = None,
        user_id: UUID | None = None,
        source: str | None = None,
        confidence: float | None = None,
        importance: int = 50,
        metadata: dict[str, Any] | None = None,
        expires_at: datetime | None = None,
    ) -> UUID:
        if not 0 <= importance <= 100:
            raise ValueError("importance must be between 0 and 100")
        if confidence is not None and not 0 <= confidence <= 100:
            raise ValueError("confidence must be between 0 and 100")

        with self.conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO memory (
                    business_id,
                    customer_id,
                    conversation_id,
                    user_id,
                    memory_type,
                    memory_key,
                    content,
                    source,
                    confidence,
                    importance,
                    metadata,
                    expires_at
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING id
                """,
                (
                    business_id,
                    customer_id,
                    conversation_id,
                    user_id,
                    memory_type,
                    memory_key,
                    content,
                    source,
                    confidence,
                    importance,
                    Jsonb(metadata or {}),
                    expires_at,
                ),
            )
            memory_id = cur.fetchone()[0]
        self.conn.commit()
        return memory_id

    def get_recent_memories(
        self,
        *,
        business_id: UUID,
        customer_id: UUID | None = None,
        limit: int = 10,
    ) -> list[dict[str, Any]]:
        limit = max(1, min(limit, 50))
        query = """
            SELECT id, memory_type, memory_key, content, source,
                   confidence, importance, metadata, created_at, expires_at
            FROM memory
            WHERE business_id = %s
              AND (expires_at IS NULL OR expires_at > NOW())
        """
        params: list[Any] = [business_id]

        if customer_id is not None:
            query += " AND (customer_id = %s OR customer_id IS NULL)"
            params.append(customer_id)

        query += " ORDER BY importance DESC, created_at DESC LIMIT %s"
        params.append(limit)

        with self.conn.cursor() as cur:
            cur.execute(query, params)
            rows = cur.fetchall()

        return [
            {
                "id": row[0],
                "memory_type": row[1],
                "memory_key": row[2],
                "content": row[3],
                "source": row[4],
                "confidence": float(row[5]) if row[5] is not None else None,
                "importance": row[6],
                "metadata": row[7],
                "created_at": row[8],
                "expires_at": row[9],
            }
            for row in rows
        ]
